for(var i = 0; i < 146; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u115'] = 'top';gv_vAlignTable['u122'] = 'center';gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u130'] = 'top';gv_vAlignTable['u79'] = 'top';gv_vAlignTable['u140'] = 'top';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u135'] = 'center';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u101'] = 'top';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u105'] = 'top';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u138'] = 'top';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u120'] = 'center';gv_vAlignTable['u110'] = 'center';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u108'] = 'top';gv_vAlignTable['u141'] = 'top';gv_vAlignTable['u68'] = 'center';gv_vAlignTable['u89'] = 'center';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u103'] = 'top';gv_vAlignTable['u99'] = 'top';gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u78'] = 'top';document.getElementById('u119_img').tabIndex = 0;

u119.style.cursor = 'pointer';
$axure.eventManager.click('u119', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Elementos.html');

}
});
gv_vAlignTable['u125'] = 'top';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u38'] = 'center';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u128'] = 'top';gv_vAlignTable['u85'] = 'top';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u100'] = 'top';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u144'] = 'top';gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u36'] = 'center';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u95'] = 'top';gv_vAlignTable['u61'] = 'center';gv_vAlignTable['u116'] = 'top';gv_vAlignTable['u74'] = 'center';gv_vAlignTable['u114'] = 'top';gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u126'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u98'] = 'top';gv_vAlignTable['u127'] = 'top';gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u142'] = 'top';gv_vAlignTable['u106'] = 'top';gv_vAlignTable['u40'] = 'center';gv_vAlignTable['u139'] = 'top';gv_vAlignTable['u87'] = 'top';gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u104'] = 'top';gv_vAlignTable['u84'] = 'top';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u97'] = 'top';document.getElementById('u63_img').tabIndex = 0;

u63.style.cursor = 'pointer';
$axure.eventManager.click('u63', function(e) {

if (true) {

}
});
gv_vAlignTable['u76'] = 'center';gv_vAlignTable['u81'] = 'top';gv_vAlignTable['u94'] = 'top';gv_vAlignTable['u102'] = 'top';gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u91'] = 'center';gv_vAlignTable['u131'] = 'top';gv_vAlignTable['u64'] = 'center';gv_vAlignTable['u70'] = 'center';gv_vAlignTable['u117'] = 'top';gv_vAlignTable['u113'] = 'top';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u129'] = 'top';gv_vAlignTable['u86'] = 'top';gv_vAlignTable['u83'] = 'top';gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u96'] = 'top';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u124'] = 'center';gv_vAlignTable['u80'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u93'] = 'top';gv_vAlignTable['u145'] = 'top';gv_vAlignTable['u137'] = 'top';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u77'] = 'top';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u143'] = 'top';gv_vAlignTable['u107'] = 'top';gv_vAlignTable['u136'] = 'top';gv_vAlignTable['u28'] = 'top';