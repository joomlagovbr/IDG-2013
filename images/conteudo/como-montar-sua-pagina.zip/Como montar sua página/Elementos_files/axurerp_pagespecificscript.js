for(var i = 0; i < 191; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u115'] = 'center';gv_vAlignTable['u122'] = 'top';gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u156'] = 'center';gv_vAlignTable['u130'] = 'top';gv_vAlignTable['u79'] = 'center';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u135'] = 'top';gv_vAlignTable['u42'] = 'center';document.getElementById('u159_img').tabIndex = 0;

u159.style.cursor = 'pointer';
$axure.eventManager.click('u159', function(e) {

if (true) {

	ScrollToWidget('u165', false,true,'none',500);

}
});
gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u101'] = 'top';gv_vAlignTable['u186'] = 'top';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u105'] = 'top';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u138'] = 'top';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u120'] = 'top';gv_vAlignTable['u110'] = 'top';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u108'] = 'top';gv_vAlignTable['u141'] = 'center';u75.tabIndex = 0;

u75.style.cursor = 'pointer';
$axure.eventManager.click('u75', function(e) {

if (true) {

	ScrollToWidget('u153', false,true,'none',500);

}
});
gv_vAlignTable['u75'] = 'top';gv_vAlignTable['u133'] = 'top';gv_vAlignTable['u68'] = 'center';gv_vAlignTable['u89'] = 'top';gv_vAlignTable['u184'] = 'top';gv_vAlignTable['u185'] = 'top';u72.tabIndex = 0;

u72.style.cursor = 'pointer';
$axure.eventManager.click('u72', function(e) {

if (true) {

	ScrollToWidget('u150', false,true,'none',500);

}
});
gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u103'] = 'top';gv_vAlignTable['u164'] = 'center';gv_vAlignTable['u99'] = 'top';gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u112'] = 'top';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u119'] = 'top';gv_vAlignTable['u125'] = 'top';gv_vAlignTable['u172'] = 'top';gv_vAlignTable['u149'] = 'center';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u118'] = 'top';gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u189'] = 'top';gv_vAlignTable['u38'] = 'center';gv_vAlignTable['u176'] = 'top';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u174'] = 'top';gv_vAlignTable['u128'] = 'top';gv_vAlignTable['u85'] = 'top';gv_vAlignTable['u182'] = 'top';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u100'] = 'top';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u36'] = 'center';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u61'] = 'center';gv_vAlignTable['u158'] = 'center';u74.tabIndex = 0;

u74.style.cursor = 'pointer';
$axure.eventManager.click('u74', function(e) {

if (true) {

	ScrollToWidget('u152', false,true,'none',500);

}
});
gv_vAlignTable['u74'] = 'top';gv_vAlignTable['u123'] = 'top';gv_vAlignTable['u160'] = 'center';document.getElementById('u157_img').tabIndex = 0;

u157.style.cursor = 'pointer';
$axure.eventManager.click('u157', function(e) {

if (true) {

	ScrollToWidget('u165', false,true,'none',500);

}
});
gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u46'] = 'center';document.getElementById('u126_img').tabIndex = 0;

u126.style.cursor = 'pointer';
$axure.eventManager.click('u126', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Exemplo.html');

}
});
gv_vAlignTable['u181'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u98'] = 'top';gv_vAlignTable['u127'] = 'center';gv_vAlignTable['u169'] = 'center';gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u187'] = 'top';gv_vAlignTable['u106'] = 'top';gv_vAlignTable['u40'] = 'center';gv_vAlignTable['u139'] = 'top';gv_vAlignTable['u87'] = 'top';gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u104'] = 'top';gv_vAlignTable['u121'] = 'top';document.getElementById('u155_img').tabIndex = 0;

u155.style.cursor = 'pointer';
$axure.eventManager.click('u155', function(e) {

if (true) {

	ScrollToWidget('u165', false,true,'none',500);

}
});
gv_vAlignTable['u109'] = 'top';gv_vAlignTable['u84'] = 'top';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u97'] = 'top';document.getElementById('u63_img').tabIndex = 0;

u63.style.cursor = 'pointer';
$axure.eventManager.click('u63', function(e) {

if (true) {

}
});
gv_vAlignTable['u170'] = 'top';u76.tabIndex = 0;

u76.style.cursor = 'pointer';
$axure.eventManager.click('u76', function(e) {

if (true) {

	ScrollToWidget('u154', false,true,'none',500);

}
});
gv_vAlignTable['u76'] = 'top';gv_vAlignTable['u134'] = 'top';gv_vAlignTable['u81'] = 'center';gv_vAlignTable['u94'] = 'center';gv_vAlignTable['u190'] = 'top';gv_vAlignTable['u102'] = 'top';gv_vAlignTable['u9'] = 'top';u73.tabIndex = 0;

u73.style.cursor = 'pointer';
$axure.eventManager.click('u73', function(e) {

if (true) {

	ScrollToWidget('u151', false,true,'none',500);

}
});
gv_vAlignTable['u73'] = 'top';gv_vAlignTable['u147'] = 'top';document.getElementById('u163_img').tabIndex = 0;

u163.style.cursor = 'pointer';
$axure.eventManager.click('u163', function(e) {

if (true) {

	ScrollToWidget('u165', false,true,'none',500);

}
});
gv_vAlignTable['u91'] = 'top';gv_vAlignTable['u64'] = 'center';gv_vAlignTable['u70'] = 'center';gv_vAlignTable['u188'] = 'top';gv_vAlignTable['u162'] = 'center';gv_vAlignTable['u113'] = 'top';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u132'] = 'center';gv_vAlignTable['u175'] = 'top';gv_vAlignTable['u129'] = 'top';gv_vAlignTable['u86'] = 'top';gv_vAlignTable['u183'] = 'top';gv_vAlignTable['u173'] = 'top';gv_vAlignTable['u111'] = 'top';gv_vAlignTable['u171'] = 'top';gv_vAlignTable['u83'] = 'top';gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u96'] = 'center';gv_vAlignTable['u146'] = 'top';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u124'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u167'] = 'center';gv_vAlignTable['u145'] = 'center';gv_vAlignTable['u137'] = 'top';gv_vAlignTable['u90'] = 'top';gv_vAlignTable['u18'] = 'top';document.getElementById('u161_img').tabIndex = 0;

u161.style.cursor = 'pointer';
$axure.eventManager.click('u161', function(e) {

if (true) {

	ScrollToWidget('u165', false,true,'none',500);

}
});
gv_vAlignTable['u77'] = 'top';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u143'] = 'center';gv_vAlignTable['u107'] = 'top';gv_vAlignTable['u136'] = 'top';gv_vAlignTable['u180'] = 'center';gv_vAlignTable['u28'] = 'top';